"use client";

import { useState, useEffect } from "react";
import { Loader2 } from "lucide-react";
import { LoginScreen } from "@/components/login-screen";
import { StudentApp } from "@/components/student-app";
import { AdminDashboard } from "@/components/admin-dashboard";
import { MentorDashboard } from "@/components/mentor-dashboard";

export default function Home() {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch("/api/auth", { credentials: "same-origin" });
        const data = await res.json();
        setUser(data.user);
      } catch {
        // ignore
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  async function handleLogin(u: any) {
    // Verify the session is set by calling GET /api/auth
    // This ensures the cookie is fully processed by the browser
    // before the dashboard renders and starts making API calls
    try {
      const res = await fetch("/api/auth", { credentials: "same-origin" });
      const data = await res.json();
      if (data.user) {
        setUser(data.user);
        return;
      }
    } catch {
      // If verification fails, fall back to the login response user
    }
    // Fallback: use the user from the login response
    setUser(u);
  }

  function handleLogout() {
    setUser(null);
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-950 via-purple-950/40 to-slate-900">
        <Loader2 className="w-8 h-8 animate-spin text-purple-400" />
      </div>
    );
  }

  if (!user) {
    return <LoginScreen onLogin={handleLogin} />;
  }

  if (user.role === "ADMIN" || user.role === "SUB_ADMIN") {
    return <AdminDashboard user={user} onLogout={handleLogout} />;
  }

  if (user.role === "MENTOR") {
    return <MentorDashboard user={user} onLogout={handleLogout} />;
  }

  return <StudentApp user={user} onLogout={handleLogout} />;
}
